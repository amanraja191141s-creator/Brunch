import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

test('CI caches npm downloads without requiring a missing lockfile', () => {
  assert.equal(fs.existsSync('package-lock.json'), false,
    'this release intentionally uses npm install without a committed lockfile');
  assert.ok(workflow.includes('uses: actions/cache@v4'));
  assert.ok(workflow.includes('path: ~/.npm'));
  assert.ok(workflow.includes("hashFiles('**/package.json')"));
  assert.ok(workflow.includes('npm-${{ runner.os }}-node24-'));
  assert.ok(workflow.includes("node-version: '24'"));
  assert.ok(workflow.includes('package-manager-cache: false'));
});

test('npm cache is restored before dependency installation', () => {
  assert.ok(workflow.indexOf('name: Cache npm downloads') < workflow.indexOf('name: Install npm dependencies'));
  assert.ok(pkg.dependencies['@capacitor/core']);
  assert.ok(pkg.dependencies['@capacitor/android']);
});

test('v98.80 release identity is synchronized across package, runtime, HTML, PWA and service worker', () => {
  const expected = '1.98.94-v98.80';
  assert.equal(pkg.version, expected);
  assert.equal(pkg.androidVersionCode, 1099001);
  assert.ok(fs.readFileSync('index.html', 'utf8').includes(expected));
  assert.ok(fs.readFileSync('assets/js/app.js', 'utf8').includes(`const APP_VERSION = '${expected}'`));
  assert.equal(JSON.parse(fs.readFileSync('manifest.webmanifest', 'utf8')).version, expected);
  assert.match(fs.readFileSync('service-worker.js', 'utf8'), /sa-calculator-v98-80-action-time-gst-unit-hardened-v9880/);
});

test('Android workflow test-entry validation rejects merged test-path tokens', () => {
  const command = pkg.scripts['test:release'];
  assert.equal(workflow.includes("tests/action-time-lifecycle-hardening-v9880.test.mjs tests/action-time-ui-geometry-v9880.test.mjs"), false);
  const commandFiles = [...command.matchAll(/(?:^|\s)(tests\/[^\s]+)/g)].map(m => m[1]);
  assert.ok(commandFiles.length >= 10);
  for (const file of commandFiles) assert.equal(fs.existsSync(file), true, `release test entry references missing file: ${file}`);
  const workflowListStart = workflow.indexOf('for(const f of [');
  const workflowListEnd = workflow.indexOf(']) {', workflowListStart);
  const workflowList = workflow.slice(workflowListStart, workflowListEnd);
  const workflowTestFiles = [...workflowList.matchAll(/'(tests\/[^']+\.test\.(?:mjs|js))'/g)].map(m => m[1]);
  assert.ok(workflowTestFiles.length >= 7);
  for (const file of workflowTestFiles) {
    assert.equal(fs.existsSync(file), true, `workflow verification list references missing file: ${file}`);
    assert.ok(commandFiles.includes(file), `workflow verification file is not in release test entry: ${file}`);
  }
});

test('Android workflow validates real v98.80 test paths and release code', () => {
  assert.ok(workflow.includes('if(p.androidVersionCode!==1099001)'));
  assert.ok(workflow.includes('tests/tool-restoration-regression-v9870.test.mjs'));
  assert.ok(workflow.includes("tests/tool-reference-video-regression-v9873.test.mjs"));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9880.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-video-regression-v9873.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9880.test.mjs'));
  assert.ok(pkg.scripts['test:release'].includes('tests/tool-reference-video-regression-v9873.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9880.test.mjs'));
  assert.ok(pkg.scripts['test:release'].includes('tests/tool-reference-finance-regression-v9880.test.mjs'));
  assert.ok(!workflow.includes('tests/tool-removal-regression-v9869.test.mjs'));
  for (const file of ['tests/tool-restoration-regression-v9870.test.mjs', 'assets/js/app.js', 'assets/css/app.css', 'assets/css/tool-reference-ui.css']) {
    assert.equal(fs.existsSync(file), true, `required workflow file missing: ${file}`);
  }
});

test('release JavaScript source has no literal escaped v98.80 hardening suffix', () => {
  const app = fs.readFileSync('assets/js/app.js', 'utf8');
  assert.ok(!app.includes('\\n\\n/* v98.80 TOOL BEHAVIOR HARDENING'),
    'app.js contains a literal escaped-newline hardening suffix; JavaScript would fail syntax validation');
  assert.ok(!fs.readFileSync('assets/css/tool-reference-ui.css', 'utf8').includes('\\n\\n/* v98.80:'),
    'tool-reference-ui.css contains a literal escaped-newline suffix');
});
